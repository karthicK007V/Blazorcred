﻿using Microsoft.EntityFrameworkCore;
using System;

namespace BlazorApp1.Models
{

		public class  DatabaseContext : DbContext
		{
			public DatabaseContext(DbContextOptions<DatabaseContext> options)
					: base(options)
			{
			}

			public DbSet<Person> Person { get; set; }
		}
	}
