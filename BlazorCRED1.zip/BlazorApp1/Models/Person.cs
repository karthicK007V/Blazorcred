﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace BlazorApp1.Models
{
	[Index(nameof(Email), IsUnique = true)]
	public class Person
	{

		[Key]
		public int Id { get; set; }
		[Required]
		public string Name { get; set; }

		[Required]
        [EmailAddress]

        public string Email { get; set; }
		[Required]
		[Unicode]
		public double? PhoneNumber { get; set; }
        [Required]
        public string Designation { get; set; }
        [Required]

        public int? Salary { get; set; }

		[DefaultValue("true")]
		public bool Active { get; set; }
	}
}
